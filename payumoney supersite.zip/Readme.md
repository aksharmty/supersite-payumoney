Payumoney Payment Gateway Integration on Supersite2

Just download all files on your server and change merchant key and salt as per your Payumoney account.

More details of setup view video : https://www.youtube.com/watch?v=UcDPd80752A&t=308s 